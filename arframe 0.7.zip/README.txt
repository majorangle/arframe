Operating system, Windows
Download AutoIt to use, https://www.autoitscript.com/site/autoit/downloads/
Game, Warframe
Tested Functional Full Screen resolution 1920x1080

Press End to close/exit ; In case an issue emergency exit also.
Press CAPSLOCK to turn on or off

Start Alpha.au3 to run